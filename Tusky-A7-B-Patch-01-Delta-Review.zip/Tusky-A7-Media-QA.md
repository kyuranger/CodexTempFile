# Tusky A7 Media QA

2026-09-08 · P01 当前有效 · **PHASE_2D_A7_B_P01_REVIEW_READY**

## 媒体映射与读取

VERIFIED：本补丁没有新生成、重新编码、擦码、翻转或写入 A/B/C。批准源为 `D:/Temp/ImageA.png`、`ImageB.png`、`ImageC.png`；现有项目 PNG 与 WebP 均相对于 P01 输入基线逐字节不变。完整母图保留，delta ZIP 只带路径/hash，不重复带媒体。原记录 `media-integration/media-records.json` 保留为 A7-B 历史证据。

| ID | 原像素 | 比例 | P01用途 |
|---|---|---|---|
| A | 1877×838 | 2.2399:1 | C2 >700px，包括820平板；完整横图 |
| B | 1122×1402 | 0.8003:1 | C2 ≤700px；完整竖图，曲线/文字覆盖左侧留白 |
| C | 1448×1086 | 4:3 | C3；宽屏16:10 CSS取景，手机完整4:3 |

| ID | assets文件 | bytes | SHA-256 |
|---|---|---:|---|
| A | `tusky_phoenix_lifecycle_desktop.png` | 1413564 | `32c71981fff2b57a4bdde1d102fb000fd942a53a31fd4ee8370342d075ad9082` |
| A | `tusky_phoenix_lifecycle_desktop.webp` | 48948 | `7d876f49ca86724bc6a128a69072624dd9bfaee900d1d84e0aebd96611262308` |
| B | `tusky_phoenix_lifecycle_mobile.png` | 1475577 | `ff3b8c221ccc3eb7c33fbcc1a7070ca7aaec2394eb15de02a3834311b2596616` |
| B | `tusky_phoenix_lifecycle_mobile.webp` | 57894 | `75740b572be3f32224fa71ae5695e8e36ea6712aad9ddf8c9c9024e2c4b90800` |
| C | `tusky_phoenix_alternative_carriers.png` | 1739159 | `1632315557a1345bf55d6208bad116d9d39409ead48f726e2c2cb87b3e356cf4` |
| C | `tusky_phoenix_alternative_carriers.webp` | 93466 | `2d54d2d27b8704eb9addd6a7d502188095dae9f92498a16ea9f179f8fa9c1e1a` |

WebP合计200308 bytes；本补丁没有改变其质量或尺寸。六尺寸实际网络载入与decode正常，A/B断点资源选择正确，无404。

## 视觉与证据边界

INSPECTED：A/B 主瓶在右侧，源点、标签和曲线位于左/中留白；原QR仍在瓶体下部，无装饰覆盖。C瓶、纸标签、金属牌、右侧圆形挂片全部可见；前三个的QR保留，圆形挂片没有QR，也不认定为RFID。C宽屏裁切只调整取景，不改变文件；1440/820的实际截图确认必需物体和QR完整。

所有媒体保留 `AI_GENERATED_REALISTIC_CONCEPT_MEDIA` / `NOT_ALLOWED_AS_EVIDENCE`。中性 alt 只描述可见对象；不称真实客户案例、实际材料结果、生产验证或已实现绑定关系。

本次 Owner 明确要求减少公开原型语言；旧“概念示意”caption已移除，旧 Decision 的逐图caption方向由 Patch01 supersede。C2在结语下保留信息/业务接入范围句，C3在媒体后的六路线说明旁保留赋码/读取/系统接入范围句；避免照片被当作任意路线已兼容的证明。描述不包含永久、耐久、全兼容、自动迁移，亦不把AI圆片当RFID实物证据。

尚未获得 Product Owner 最终视觉接受；未验证真机、Safari/Firefox、真人读屏、系统文字放大或生产服务。沿用原型字体子集，新增字形可能使用系统 fallback，跨平台完整字体覆盖未验证。AI 图与 QR 不构成生产结果、扫码可用性、客户案例或兼容性证据。
