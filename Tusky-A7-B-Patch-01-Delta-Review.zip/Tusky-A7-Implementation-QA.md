# Tusky A7 Implementation QA

2026-09-08 · P01 当前有效 · **PHASE_2D_A7_B_P01_REVIEW_READY**

## 范围与运行

实际修改 `prototypes/phase-2d-a5-3/tusky_phoenix/index.html`、`assets/tusky_phoenix_lifecycle.css`、`assets/tusky_phoenix_lifecycle.js` 中 C2/C3；沿用现有静态原型。Hero 与图片/字体二进制未变。localhost `http://127.0.0.1:8767/` 完整显示三章。

TESTED：Windows、Edge 152.0.4191.66 headless、Playwright 隔离浏览器上下文、DPR 1、HTTP 实际载入、原生滚动/键盘。每种尺寸都等待字体与媒体 decode。机器明细为 `media-integration/patch-01/validation.json`，不得沿用旧 A7-B 的通过结论代替此次结果。

## 响应式与完整页面

| Viewport | Hero宽 | C2媒体宽 | C3媒体宽 | C2整章高 | C2共享画面高 | Motion |
|---|---:|---:|---:|---:|---:|---|
| 1440×900 | 1360 | 1360 | 1360 | 1382.8 | 607.2 | desktop |
| 1024×900 | 968 | 944 | 944 | 1181.9 | 421.5 | desktop |
| 820×1180 | 780 | 780 | 780 | 738.7 | 348.2 | flow |
| 430×932 | 398 | 398 | 398 | 898.8 | 497.3 | flow |
| 390×844 | 358 | 358 | 358 | 848.8 | 447.3 | flow |
| 320×740 | 296 | 296 | 296 | 797.2 | 369.9 | flow |

MEASURED：全部六尺寸 overflow=0；C2 `.lifecycle__field` 与照片宽高/顶部完全相同；信息与 trace 位于照片留白且不越过瓶体左边界；文本对比度保守采样（整个文字外接矩形的底图像素）最低 5.50:1，满足所用 3:1/4.5:1 阈值。此项仅证明该底图/颜色采样，不代替完整无障碍认证。

INSPECTED：六个 reduced 全页图用于判断 Hero → C2 → C3 的完整尺度和阅读顺序；正常动效另有 1440/390 entry/midpoint/final 六图、两张交接 viewport 图。C3 有 1440/820/390 整章元素截图（跨 viewport），不误标为单屏。另有 390 no-JS 全页，共18张本补丁证据。缩略图可点击原始截图看文字。

## 功能与冻结项

TESTED：六尺寸均 1 个 H1、2 个 H2；六路线 DOM 顺序正确；所有文字本来就在 HTML 中，没有第二份移动端语义文案。公开正文无“概念示意 / 示意 / prototype / demo / future capability / PROTOTYPE_ / NEEDS_”。状态保留在 data attributes；图片中性 alt，装饰 SVG 不增加重复语义。没有 JS 异常或 HTTP 4xx/5xx；12组静态回退、7组 resize、reduced 动态切换通过。

VERIFIED：Hero 起始源码至 C2 之前的字节完全匹配 P01 输入基线；所有冻结图片/字体 hash 匹配。六尺寸 Hero 对照最终均 pixel channel diff=0。首次320截图曾有128481个通道差异，范围仅在图片栅格区；相同布局/相同字节的基线控制也可出现该差异。统一 fonts.ready + decode + 500ms 等待、一次预截图及200ms等待后，同浏览器加载 P01 前 HTML/CSS/JS 对照与当前图均为0。没有为消除测量差异修改 Hero。

本轮仅涉及独立静态原型，未运行整个网站 Solution Build 或生产发布；没有新增依赖。

尚未获得 Product Owner 最终视觉接受；未验证真机、Safari/Firefox、真人读屏、系统文字放大或生产服务。沿用原型字体子集，新增字形可能使用系统 fallback，跨平台完整字体覆盖未验证。AI 图与 QR 不构成生产结果、扫码可用性、客户案例或兼容性证据。

Git：main；HEAD / fresh origin/main 均为 `2e62e4eb9bf8ed72a91c22ab7a8e2498bc754c5f`；Ahead 0 / Behind 0；DirtyUpToDate。保留已授权的既有 dirty 工作区；未 commit，尚未推送。
