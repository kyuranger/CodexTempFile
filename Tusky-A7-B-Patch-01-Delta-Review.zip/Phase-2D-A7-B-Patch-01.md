# Phase 2D-A7-B Patch 01

2026-09-08 · **PHASE_2D_A7_B_P01_REVIEW_READY** · 等待 Product Owner / ChatGPT review。

## 结果与有效决策

A7-B 前一结果被 Owner 判定 **NOT ACCEPTED / PHASE_2D_A7_B_NEEDS_REWORK**。本补丁完成 C2/C3 的有界重做；REVIEW_READY 表示可评审，不表示 Owner 已接受。Hero 继续冻结。

1. C2 手机选择 Owner 允许的 A 方案：Image B 是唯一共享容器，HTML 身份、三组信息和累积曲线直接置于照片左侧留白。同一套语义内容，只有装饰 SVG 随断点换几何。390×844 整章由 1642.4px 降为 848.8px，减少 48.3%；照片与关系场同为 358×447.3px，不再有后接 700px 独立 SVG。全部标签保留。
2. C2 新增日期/批次、工序/操作员、出库/物流、渠道/销售、保修/售后信息。开头以“可关联的信息包括”组织内容，结尾说明查找单件产品时这些记录拥有共同线索。客户能识别信息类型及同一标识的实际作用，不把旧源字段表述为当前生产版本已经完整交付。
3. C3 采用大幅静物媒体与开放式文字 rail，明确命名喷码、激光标识、标签、金属标牌、RFID、TTO。桌面按内容宽度排列，手机两列三行；无卡片、图标组、能力矩阵或六个产品模块。短句帮助区分工艺与载体，再由材料、包装、使用条件进入选型讨论。
4. C2/C3 媒体在 1440px 为 1360px，与 Hero 同宽；820px 为 780px，同样与 Hero 对齐。文字单独限制阅读宽度。700px 及以下使用 B，701px 以上使用 A；820 平板由窄竖图改为宽横向一体画面。
5. 删除反复可见的“概念示意”与内部状态措辞，使用中性 alt。C2 保留“具体信息范围与业务接入方式，按实际应用确认。”；C3 六路线后紧邻“具体赋码、读取与系统接入方式，需结合实际应用确认。”，该范围句属于整组媒体/路线的选择条件。无需恢复逐图概念图注。
6. A/B/C PNG 与现有 WebP、Hero 图/字体全部保留原字节与 QR。C3 宽屏 16:10 CSS 取景只去掉上下留白，必需物体与 QR 均在画面内；手机完整 4:3。C3 保持静态。C2 同源累积、回撤及自然滚动保留；仅桌面媒体场短暂 sticky，平板/手机不额外拉长滚动。

## 内容输入审计

INSPECTED：`docs/rebuild-audit/phase-2d-a4-2-patch-01a/Direct-Legacy-Value-Proposition-Inventory.md`、同目录 `Direct-Legacy-Source-Audit.md`、`docs/rebuild-audit/phase-2d-a4-3/Tusky-Phoenix-Content-Story-Architecture.md`（37–40、55–65 行）、`docs/rebuild-audit/phase-1d/Product-Claim-Registry-V2.md`（CLM-TP-001，26–28 行），并交叉核对 A6 Story Inputs 和下列真实旧源。没有修改旧项目。

表中 `legacy` 的精确路径是 `D:/Project/SealIndustry/SealIndustry/Resources/Views/CommercialProducts/traceable_deer.zh-hans.resx`。`SOURCE_SUPPORTED` 仅指该旧源有依据；所有本轮示例的当前生产能力仍是 `NEEDS_VERIFICATION`。这张表仅在评审文档中，不出现在网页 UI。

| Visible Term | Source | Current Status | Allowed Public Wording |
|---|---|---|---|
| 一物一码 / 同一标识 | Claim Registry CLM-TP-001；Story Architecture | 产品主张范围保留；不扩展为字段/模块清单已交付 | 凰牙以一物一码关联产品信息；记录有共同线索 |
| 日期 · 批次 | legacy:145 `BringsDate` | SOURCE_SUPPORTED；当前 NEEDS_VERIFICATION | 可关联的信息示例：日期、批次 |
| 工序 · 操作员 | legacy:160 `BringsProcedure` | SOURCE_SUPPORTED；当前 NEEDS_VERIFICATION | 生产时：工序、操作员；不宣称全流程自动采集 |
| 出库 · 物流 | legacy:145 `BringsDate`、151 `BringsLogistics` | SOURCE_SUPPORTED；当前 NEEDS_VERIFICATION | 流转中：出库、物流；不宣称实时第三方物流接入 |
| 渠道 · 销售 | legacy:142 `BringsCustomer`、145 `BringsDate` | SOURCE_SUPPORTED；当前 NEEDS_VERIFICATION | 渠道、销售信息；不扩展为现成渠道防窜货/分析能力 |
| 保修记录 / 售后信息 | legacy:163 `BringsSalesFollow` | SOURCE_SUPPORTED；当前 NEEDS_VERIFICATION | 售后时：保修记录、售后信息；不承诺全国联保/无纸保修 |
| 喷码 | legacy:258–261 inkjet | SOURCE_SUPPORTED；当前接入 NEEDS_VERIFICATION | 油墨形成标识 |
| 激光标识 | legacy:269–273 laser | SOURCE_SUPPORTED；当前接入 NEEDS_VERIFICATION | 材料表面的标识工艺；不使用“永久”“防篡改” |
| 标签 | legacy:264–267 label | SOURCE_SUPPORTED；当前接入 NEEDS_VERIFICATION | 贴附式载体；不承诺自动贴标设备兼容 |
| 金属标牌 | Owner 本补丁明确命名与批准 C；legacy:276–279 另记录机械金属标记 | CARRIER_CONCEPT_NOT_COMPATIBILITY；旧机械工艺不等于独立标牌 | 独立标识载体；不宣称耐久、材质兼容或图中制造工艺 |
| RFID | legacy:281–285 RFID | SOURCE_SUPPORTED；当前接入 NEEDS_VERIFICATION | 射频识别技术；不把 C 的圆形挂片认作 RFID |
| TTO | legacy:287–291 TTO | SOURCE_SUPPORTED；当前接入 NEEDS_VERIFICATION | 热转印赋码；不扩展为柔性包装/设备全兼容 |

排除 legacy:148 的用户资料采集/画像及 :154 的营销、红包、抽奖（NOT_PUBLIC），并排除耐久、防伪性能、RFID 读写协议、自动迁移、多载体同时绑定等无当前验证结论。新的展示密度由本次 Owner 指令授权；A6 较少示例只是旧展示范围，不是永久禁用这些旧源词汇。

## 验证与交接

MEASURED / TESTED：六尺寸无横向溢出，照片与关系场边界逐一相同；三组关系终态均为 1；手机终态三组标签同时处于 viewport 内。12 组 reduced-motion / no-JS 均完整静态显示，7 组 resize 与动态 reduced 切换通过。六尺寸 Hero 稳定栅格比较均为 0 差异；源码前缀与批准媒体 hash 不变。INSPECTED：全页六尺寸及桌面/手机三态、交接、C3 实际截图；没有改动 Hero 或将内容拆回图表堆叠。

| Viewport | Hero宽 | C2媒体宽 | C3媒体宽 | C2整章高 | C2共享画面高 | Motion |
|---|---:|---:|---:|---:|---:|---|
| 1440×900 | 1360 | 1360 | 1360 | 1382.8 | 607.2 | desktop |
| 1024×900 | 968 | 944 | 944 | 1181.9 | 421.5 | desktop |
| 820×1180 | 780 | 780 | 780 | 738.7 | 348.2 | flow |
| 430×932 | 398 | 398 | 398 | 898.8 | 497.3 | flow |
| 390×844 | 358 | 358 | 358 | 848.8 | 447.3 | flow |
| 320×740 | 296 | 296 | 296 | 797.2 | 369.9 | flow |

当前 QA 及机器记录：`Tusky-A7-Implementation-QA.md`、`Tusky-A7-Motion-QA.md`、`Tusky-A7-Media-QA.md`、`media-integration/patch-01/validation.json`、`integrity.json`。完整交互：[localhost](http://127.0.0.1:8767/)。离线评审从 `START-HERE.html` / `REVIEW-MANIFEST.md` 开始；`Tusky-A7-B-Patch-01-Delta-Review.zip` 只含补丁变化，源图/字体以路径与 hash 引用。

本补丁 supersede 前 A7-B 的窄画布、820 使用 B、移动照片后接独立关系场、原 C2/C3 文案、逐图 caption、C3 宽屏固定 4:3 和旧几何/timing 结论。前一 Decision 保留历史记录并添加失效说明；品牌、Product Detail Base、证据边界、Hero 冻结与 A6 同源累积概念仍有效。未进入 Chapter4。

尚未获得 Product Owner 最终视觉接受；未验证真机、Safari/Firefox、真人读屏、系统文字放大或生产服务。沿用原型字体子集，新增字形可能使用系统 fallback，跨平台完整字体覆盖未验证。AI 图与 QR 不构成生产结果、扫码可用性、客户案例或兼容性证据。

Git：main；HEAD / fresh origin/main 均为 `2e62e4eb9bf8ed72a91c22ab7a8e2498bc754c5f`；Ahead 0 / Behind 0；DirtyUpToDate。保留已授权的既有 dirty 工作区；未 commit，尚未推送。

当前范围内实施与验证完成，等待 Owner / ChatGPT 对整合感、信息密度、页面尺度和路线表达进行评审；本阶段停止。
